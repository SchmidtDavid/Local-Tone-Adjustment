%function greyColorImg = greyscale_with_color(negative, subImg)
negative = 'exampleSubImg.jpg';
subImg = 'exampleNegativeImg.jpg';

subImg = imread(subImg);
negative = imread(negative);

finImg = rgb2gray(negative) + subImg;
imwrite(finImg, './ResultImages/greyWithColor.jpg');