%function recolored = absoluteColor(subImg, redRatio, greenRatio, blueRatio)

% Hard Coded Values
subImg = './exampleSubImg.jpg';
negImg = 'exampleNegativeImg.jpg';
redRatio = .553;
greenRatio = .2;
blueRatio = .714;

img = imread(subImg);
negImg = imread(negImg);

R = img(:, :, 1);
G = img(:, :, 2);
B = img(:, :, 3);
isBlack = R == 0 & B == 0 & G == 0;
R(~isBlack) = 255;
G(~isBlack) = 255;
B(~isBlack) = 255;
whiteImg = cat(3, R, G, B);
%imwrite(whiteImg, 'whiteImg.jpg');

%recolored = relativeColor('./whiteImg.jpg', redRatio, greenRatio, blueRatio);
%IMPORTANT: Replaced ^ with the code from relativeColor for easy running.

img = whiteImg;
R = img(:,:,1);
G = img(:,:,2);
B = img(:,:,3);
R2 = redRatio * R;
G2 = greenRatio * G;
B2 = blueRatio * B;
recolored = zeros(size(img));
recolored(:,:,1) = R2;
recolored(:,:,2) = G2;
recolored(:,:,3) = B2;
recolored = uint8(recolored);


recolored = recolored + negImg; 

imwrite(recolored, './ResultImages/absoluteColorResult.jpg');