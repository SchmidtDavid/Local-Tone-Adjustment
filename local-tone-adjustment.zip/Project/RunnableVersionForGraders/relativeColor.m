%function recolored = relativeColor()
subImg = './exampleSubImg.jpg';
negImg = 'exampleNegativeImg.jpg';

img = imread(subImg);
negImg = imread(negImg);

redRatio = 1.0;
greenRatio = 0.5;
blueRatio = 0.5;


R = img(:,:,1);
G = img(:,:,2);
B = img(:,:,3);
R2 = redRatio * R;
G2 = greenRatio * G;
B2 = blueRatio * B;
recolored = zeros(size(img));
recolored(:,:,1) = R2;
recolored(:,:,2) = G2;
recolored(:,:,3) = B2;
recolored = uint8(recolored);

recolored = recolored + negImg; 
imwrite(recolored, './ResultImages/relativeColor.jpg');