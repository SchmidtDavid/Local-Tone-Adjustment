function L2 = imgSeg_Simple(origImg)
%This fuction will segment the image based on hardcoded values and k-means
%Later parameters for k and potentially number of iterations will be added

RGB = imread(origImg);

%Create a set of 24 Gabor filters, covering 6 wavelengths and 4 orientations.
wavelength = 2.^(0:5) * 3;
orientation = 0:45:135;
g = gabor(wavelength,orientation);

%convert to grayscale
I = rgb2gray(im2single(RGB));
%Filter the grayscale image using the Gabor filters. 
gabormag = imgaborfilt(I,g);

%Smooth each filtered image to remove local variations.
for i = 1:length(g)
    sigma = 0.5*g(i).Wavelength;
    gabormag(:,:,i) = imgaussfilt(gabormag(:,:,i),3*sigma); 
end

%This additional information allows the k-means clustering algorithm to 
%prefer groupings that are close together spatially.
nrows = size(RGB,1);
ncols = size(RGB,2);
[X,Y] = meshgrid(1:ncols,1:nrows);
%Concatenate the intensity information, neighborhood texture information, 
%and spatial information about each pixel.
featureSet = cat(3,I,gabormag,X,Y);
%Segment the image into two regions using k-means clustering with the 
%supplemented feature set.
L2 = imsegkmeans(featureSet,2,'NormalizeInput',true);
