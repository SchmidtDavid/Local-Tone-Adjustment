orig = imread('galaxy.jpg');
resized = imresize(orig, size(imread('exampleImgMask.jpg')));
imwrite(resized, 'resized.jpg');

mask = imread('exampleImgMask.jpg');
mask = ~mask;
mask = uint8(mask);

background = bsxfun(@times, resized, mask);

imwrite(background, './ResultImages/bg.jpg');