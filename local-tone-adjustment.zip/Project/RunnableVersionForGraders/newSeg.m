function L = newSeg(origImg)
img = imread(origImg);

lab_img = rgb2lab(img);
 
a = lab_img(:,:,2:3);
a = im2single(a);
%change nColors to change the number of color segments that are created
nColors = 5;

% repeat the clustering 10 times to avoid local minima
L = imsegkmeans(a,nColors,'NumAttempts',10);