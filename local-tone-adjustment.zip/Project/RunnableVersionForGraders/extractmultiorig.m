function [subImg, negativeImg, imgMask] = extractmultiorig(origImg)
%EXTRACT Summary of this function goes here
%   This function's goal is to remove the labeled part of the image.
%   It should return an image that is black except for the specified
%   labeled sections from the original image
%
%origImg = './cat.jpg';
Labels = imgSeg_Simple(origImg);
img = imread(origImg);
B = labeloverlay(img,Labels);
disp('Click area(s) that you would like to modify, then click out of bounds to terminate.');
imshow(B);
objects = [];
while(true)
    [x,y] = ginput(1);
    x = round(x);
    y = round(y);
    
    out_of_bounds = ~(x < size(img, 2) && y < size(img, 1) ...
                                             && x > 1 && y > 1);
    if out_of_bounds
        break;
    end
    
    object = Labels(y, x);
    objects = [objects object];
end
if isempty(objects)
   disp('No object selected.');
   return;
end
% Creates the subObject
imgMask = Labels == objects(1);
if length(objects)> 1
    for i = 2:length(objects)
        disp('executed');
        tempMask = Labels == objects(i);
        imgMask = imgMask | tempMask;
    end
end
R = img(:, :, 1); 
G = img(:, :, 2);
B = img(:, :, 3);
R(~imgMask) = 0; 
G(~imgMask) = 0;
B(~imgMask) = 0; 

subImg = cat(3, R, G, B); 
imwrite(subImg, 'subImg.jpg');
imwrite(imgMask, 'imgMask.jpg');

% Creates the negative of the above
imgMask2 = ~imgMask;
R = img(:, :, 1); 
G = img(:, :, 2);
B = img(:, :, 3);
R(~imgMask2) = 0; 
G(~imgMask2) = 0;
B(~imgMask2) = 0; 

negativeImg = cat(3, R, G, B); 
imwrite(negativeImg, 'negativeImg.jpg');






