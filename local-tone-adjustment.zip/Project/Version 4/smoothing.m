RGB = imread('hourLater.jpg');
for c = 1 : 3
    img_filtered(:, :, c) = medfilt2(RGB(:, :, c), [3, 3]);
end
figure; imshow(img_filtered);
