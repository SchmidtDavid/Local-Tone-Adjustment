function L = newSeg(origImg)
img = imread(origImg);

lab_img = rgb2lab(img);
 
a = lab_img(:,:,2:3);
a = im2single(a);
nColors = 4;
% repeat the clustering to avoid local minima
L = imsegkmeans(a,nColors,'NumAttempts',10);