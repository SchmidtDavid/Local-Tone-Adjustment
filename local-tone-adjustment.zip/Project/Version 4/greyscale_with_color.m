function greyColorImg = greyscale_with_color(negative, subImg)

negative = imread(negative);
grey_negative = rgb2gray(negative);
imwrite(grey_negative,'grey_negative.jpg');
greyColorImg = stitch('grey_negative.jpg', subImg);
