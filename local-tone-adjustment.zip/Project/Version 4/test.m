grey = imread('cat.jpg');
grey = rgb2gray(grey);
rgbImage = cat(3, grey, grey, grey);
imwrite(rgbImage, 'greyCat.jpg');