function recolored = relativeColor(img, redRatio, greenRatio, blueRatio)
% img = './peppers.png';
% redRatio = 1.0;
% greenRatio = 1.0;
% blueRatio = 1.0;

img = imread(img);
R = img(:,:,1);
G = img(:,:,2);
B = img(:,:,3);
R2 = redRatio * R;
G2 = greenRatio * G;
B2 = blueRatio * B;
recolored = zeros(size(img));
recolored(:,:,1) = R2;
recolored(:,:,2) = G2;
recolored(:,:,3) = B2;
recolored = uint8(recolored);
imwrite(recolored, 'recolored.jpg');