function finImg = stitch(negativeImg, modImg)

%EXTRACT Summary of this function goes here
%     The goal of this function is to stitch the completed
%     modified subImage back into the original image.
% origImg = imread(origImg);
% segImg = imread(segImg);
% imgMask = imread(imgMask);

negativeImg = imread(negativeImg);
modImg = imread(modImg);

finImg = negativeImg + modImg;

%Possibly implement a smoothing or feathering algorithm
imwrite(finImg, 'finImg.jpg');