orig = imread('galaxy.jpg');
resized = imresize(orig, size(imread('imgMask.jpg')));
imwrite(resized, 'resized.jpg');

mask = imread('imgMask.jpg');
mask = ~mask;
mask = uint8(mask);
% R = resized(:, :, 1);
% G = resized(:, :, 2);
% B = resized(:, :, 3);
% % Multiply the mask by each color channel individually.
% R2 = R .* mask;
% G2 = G .* mask;
% B2 = B .* mask;
% % Recombine separate masked color channels into a single, true color RGB image.
% background = cat(3, R2, G2, B2);

background = bsxfun(@times, resized, mask);


imwrite(background, 'bg.jpg');