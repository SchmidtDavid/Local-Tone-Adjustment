function FlattenBackground()
OrigImage = 'cutecat.jpg';
RGB = imread(OrigImage);
sigma = 30;

%this creats a flattened field over the entire image
Iflatfield = imflatfield(RGB, sigma);

%extraction using L*a*b colorspace
%[sub, neg, mask] = extractmulti(OrigImage); 

%extraction using Gabor filters, intensity, and spatial information
[sub, neg, mask] = extractmultiorig(OrigImage);

%This creates a flattened field over the selected image subject 
Iflatfield2 = imflatfield(sub,sigma,mask);

newImg = stitch(neg, Iflatfield2);

imshowpair(Iflatfield,newImg,'montage')
title('Flattened Field on Entire Image vs. Extracted background')
