function LocalLaplacian()
OrigImage = 'cat.jpg'; %change this string to try with a different image
RGB = imread(OrigImage);
sigma = .2;
%alpha < 1 is a sharpen and >1 is a smoothing
alpha = .5;
%this applies the local laplacian to the entire image for comparison
LlapOrig = locallapfilt(RGB, sigma, alpha);

%extraction using L*a*b colorspace
[sub, neg, mask] = extractmulti(OrigImage); 

%extraction using Gabor filters, intensity, and spatial information
%[sub, neg, mask] = extractmultiorig(OrigImage);

%This applies the local laplacian filter to the selected region using
%color separation
LlapNew = locallapfilt(sub, sigma, alpha, 'ColorMode', 'separate');
newImg = stitch(neg, LlapNew);
imshowpair(LlapOrig,newImg,'montage')
title('Local Laplacian Filtering on Entire Image vs. Extracted subject(alpha = .5)')