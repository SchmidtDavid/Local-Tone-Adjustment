function [subImg, negativeImg, imgMask] = extractmulti(origImg)
%EXTRACT Summary of this function goes here
%   This function's goal is to remove the labeled part of the image.
%   It should return an image that is black except for the specified
%   labeled sections from the original image
%
%origImg = './cat.jpg';
Labels = newSeg(origImg);
img = imread(origImg);

disp('Click area(s) that you would like to modify, then click out of bounds to terminate.');
B = labeloverlay(img,Labels);
imshow(B);
objects = [];
while(true)
    [x,y] = ginput(1);
    x = round(x);
    y = round(y);
    
    out_of_bounds = ~(x < size(img, 2) && y < size(img, 1) ...
                                             && x > 1 && y > 1);
    if out_of_bounds
        break;
    end
    
    object = Labels(y, x);
    objects = [objects object];
end
if isempty(objects)
   disp('No object selected.');
   return;
end
% Creates the subObject
imgMask = Labels == objects(1);
if length(objects)> 1
    for i = 2:length(objects)
        tempMask = Labels == objects(i);
        imgMask = imgMask | tempMask;
    end
end

L = bwlabeln(imgMask, 8);
B = labeloverlay(img, L);
imshow(B);
disp('To finalize, select the objects you wish to keep.');
disp('Click out of bounds to terminate.');
while(true)
    [x,y] = ginput(1);
    x = round(x);
    y = round(y);
    
    out_of_bounds = ~(x < size(img, 2) && y < size(img, 1) ...
                                             && x > 1 && y > 1);
    if out_of_bounds
        break;
    end
    
    object = L(y, x);
    objects = [objects object];
end
if isempty(objects)
   disp('No object selected.');
   return;
end
imgMask2 = L == objects(1);
if length(objects)> 1
    for i = 2:length(objects)    
        tempMask = L == objects(i);
        imgMask2 = imgMask2 | tempMask;
    end
end

R = img(:, :, 1); 
G = img(:, :, 2);
B = img(:, :, 3);
R(~imgMask2) = 0; 
G(~imgMask2) = 0;
B(~imgMask2) = 0; 

subImg = cat(3, R, G, B); 
imwrite(subImg, 'subImg.jpg');
imwrite(imgMask2, 'imgMask.jpg');

% Creates the negative of the above
negMask = ~imgMask2;
R = img(:, :, 1); 
G = img(:, :, 2);
B = img(:, :, 3);
R(~negMask) = 0; 
G(~negMask) = 0;
B(~negMask) = 0; 

negativeImg = cat(3, R, G, B); 
imwrite(negativeImg, 'negativeImg.jpg');






