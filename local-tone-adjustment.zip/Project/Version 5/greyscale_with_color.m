function greyColorImg = greyscale_with_color(negative, subImg)
subImg = imread(subImg);
negative = imread(negative);

finImg = rgb2gray(negative) + subImg;
imwrite(finImg, 'finImg.jpg');