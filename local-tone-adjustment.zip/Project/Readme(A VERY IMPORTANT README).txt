****VERSIONS****
-------------------------
RunnableVersionForGraders (Recommended)
-------------------------
This version has all of the functions in instantly runnable form using hardcoded values.
We have destroyed modularity here, it's just to make it really easy to understand what's happening.
Every function in here either produces figures, creates results and places them in "/resultsFolder", or is a simple helper function left unchanged.

Just run all the matlab files that are non-helper functions  (ie: Don't run stitch, newSeg, imgSeg_Simple, or the extract functions on their own, they're called in other methods)
If desired, change the K value for the segmentations in imgSegSimple or newSeg for a different level of k-means segmentation. 
-------------------------
Version 4
-------------------------
This is the most modular version, and where most of the results images were generated. It's not super user friendly. It also has some bugs fixed in V5
At the end of this version we started to make our code more "hard coded" for ease of grading, which resulted in version 5. It's the most pure version,
but it'll take a bit of time to learn how things are passed around, and such. It's not nicely linked together.  
-------------------------
Version 5
-------------------------
This is the bridge between 4 and the Grader version. It includes a couple bug fixes (it doesn't crash when the user selects 0 objects, etc).

